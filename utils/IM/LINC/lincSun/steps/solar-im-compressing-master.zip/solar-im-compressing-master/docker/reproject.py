#!/usr/bin/env python3
from astropy.io import fits
from argparse import ArgumentParser
from astropy.wcs import WCS
from astropy.coordinates import SkyCoord, EarthLocation
import sunpy.map
import sunpy.coordinates
import matplotlib.colors as mpl_colors
import matplotlib.patches as mpl_patches
import numpy as np
import astropy.units as u
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os.path
from astropy.time import Time

LOFAR_CORE = EarthLocation.from_geocentric(x=3826560.737625 * u.m, y=461033.24679167 * u.m, z=5064904.97320833 * u.m)


def parse_args():
    parser = ArgumentParser(description='Reproject to sun coordinate')
    parser.add_argument('input', help='input file', nargs='+')
    parser.add_argument('output', help='output file')

    return parser.parse_args()


def reproject_to_heliocentric_frame(header, data, fov=3000):
    """
    Reproject the image generated using equatorial coordinates (ICRS) into
    heliocentric coordinates and changes the fix header accordingly.

    Inspired from Laura Hayes gist
    https://gist.github.com/hayesla/a842afd90aa5a01b8b4d59be8b4ceb8c
    """

    obstime = header['date-obs']
    freq = header['crval3'] * u.Hz
    cdelt1, cdelt2 = abs(header['cdelt1']), abs(header['cdelt2'])
    sun_distance = sunpy.coordinates.sun.earth_distance(obstime)
    reference_pixel = u.Quantity([header['crpix1'], header['crpix2']] * u.pixel)
    data = data.squeeze()
    scale = u.Quantity([cdelt1, cdelt2] * u.deg / u.pix)
    lofar_coord = SkyCoord(LOFAR_CORE.get_itrs(Time(obstime)))
    reference_coordinate = SkyCoord(header['crval1'] * u.deg, header['crval2'] * u.deg,
                                    frame='gcrs',
                                    observer=lofar_coord,
                                    obstime=obstime,
                                    distance=sun_distance)
    reference_coordinate_helio = reference_coordinate.transform_to(sunpy.coordinates.frames.Helioprojective)
    P1 = sunpy.coordinates.sun.P(obstime)
    header_heliocentric_frame = sunpy.map.make_fitswcs_header(data, reference_coordinate_helio,
                                                              reference_pixel=reference_pixel,
                                                              scale=scale,
                                                              rotation_angle=-P1,
                                                              wavelength=freq.to(u.MHz),
                                                              observatory='LOFAR')

    header_heliocentric_frame['HISTORY'] = header['HISTORY']
    header_heliocentric_frame['BMAJ'] = header['BMAJ']
    header_heliocentric_frame['BMIN'] = header['BMIN']
    header_heliocentric_frame['BPA'] = header['BPA']

    image_map = sunpy.map.Map(data, header_heliocentric_frame)
    image_map = image_map.rotate()

    bl = SkyCoord(-fov * u.arcsec, -fov * u.arcsec, frame=image_map.coordinate_frame)
    tr = SkyCoord(fov * u.arcsec, fov * u.arcsec, frame=image_map.coordinate_frame)
    image_map = image_map.submap(bottom_left=bl, top_right=tr)

    return image_map


def image_plotter(fig: plt.Figure, ax: plt.Axes, sunpy_map):
    p, *_ = sunpy_map.draw_limb()
    solar_angle = sunpy.coordinates.sun.P(sunpy_map.date)
    scale = 3600 / 6000
    beam0 = mpl_patches.Ellipse((.7, -.7), sunpy_map.meta['bmaj'] * scale, sunpy_map.meta['bmin'] * scale,
                                -(sunpy_map.meta['bpa']*u.deg + 90*u.deg).value, color='w', transform=ax.get_transform('world'))
    ax.add_artist(beam0)
    return [p]


def plot_solar_map(image_map, path_out):
    mapsmax = 0
    mapsmin = 10000
    for map in image_map:
        mapsmax = max([mapsmax, map.max()])
    for map in image_map:
        mapsmin = min([mapsmin, map.min()])

    for map in image_map:
        map.plot_settings['cmap'] = plt.get_cmap('rainbow')
        map.plot_settings['norm'] = mpl_colors.Normalize(mapsmin, mapsmax)

    ani = image_map.plot(plot_function=image_plotter)
    Writer = animation.writers['ffmpeg']
    writer = Writer(fps=10, bitrate=1800)
    ani.save(path_out, writer=writer)

def load_fits(path):
    hdu, *_ = fits.open(path)
    return hdu.header, hdu.data


def get_wcs_from_hdu(hdu):
    return WCS(hdu)


def main():
    args = parse_args()
    solar_maps = []
    for index, input_path in enumerate(args.input):
        print('processing image ', index + 1, 'of', len(args.input))
        header, data = load_fits(input_path)

        solar_maps += [reproject_to_heliocentric_frame(header, data)]

    solar_map_sequence = sunpy.map.Map(solar_maps, sequence=True)
    full_path = os.path.join(os.getcwd(), args.output)
    os.makedirs(full_path, exist_ok=True)
    file_basename = os.path.basename(args.input[0]).split('.')[0]

    pattern = file_basename + '_{index:04}.fits'
    solar_map_sequence.save(os.path.join(args.output, pattern), overwrite=True)
    plot_solar_map(solar_map_sequence, os.path.join(args.output, file_basename + '.mp4'))


if __name__ == '__main__':
    main()
